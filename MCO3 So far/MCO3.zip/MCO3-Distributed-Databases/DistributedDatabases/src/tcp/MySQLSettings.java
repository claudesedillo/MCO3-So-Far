package tcp;

public class MySQLSettings {
	public final static String user = "root";
	public final static String password = "1234";
}
